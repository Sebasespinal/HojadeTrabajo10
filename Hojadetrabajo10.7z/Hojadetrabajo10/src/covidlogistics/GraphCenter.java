package covidlogistics;

import java.util.*;

public class GraphCenter {
    private int[][] dist;
    private List<String> cities;

    public GraphCenter(FloydWarshall floydWarshall) {
        this.dist = floydWarshall.dist;
        this.cities = floydWarshall.cities;
    }

    public String getCenter() {
        int n = dist.length;
        int[] eccentricity = new int[n];
        Arrays.fill(eccentricity, 0);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (dist[i][j] != FloydWarshall.INF && i != j) {
                    eccentricity[i] = Math.max(eccentricity[i], dist[i][j]);
                }
            }
        }

        int centerIndex = 0;
        for (int i = 1; i < n; i++) {
            if (eccentricity[i] < eccentricity[centerIndex]) {
                centerIndex = i;
            }
        }
        return cities.get(centerIndex);
    }
}