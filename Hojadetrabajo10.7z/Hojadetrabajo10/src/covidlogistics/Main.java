package covidlogistics;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try {
            Graph graph = new Graph("guategrafo.txt");
            FloydWarshall floydWarshall = new FloydWarshall(graph);
            GraphCenter graphCenter = new GraphCenter(floydWarshall);

            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.println("\nOpciones:");
                System.out.println("1. Ruta más corta entre dos ciudades");
                System.out.println("2. Ciudad centro del grafo");
                System.out.println("3. Modificar grafo");
                System.out.println("4. Finalizar programa");
                System.out.print("Seleccione una opción: ");
                int option = scanner.nextInt();
                scanner.nextLine();

                switch (option) {
                    case 1:
                        System.out.print("Ingrese la ciudad origen: ");
                        String start = scanner.nextLine();
                        System.out.print("Ingrese la ciudad destino: ");
                        String end = scanner.nextLine();
                        List<String> path = floydWarshall.getShortestPath(start, end);
                        int distance = floydWarshall.getShortestDistance(start, end);
                        if (path == null) {
                            System.out.println("No existe ruta entre " + start + " y " + end);
                        } else {
                            System.out.println("Ruta más corta: " + path);
                            System.out.println("Distancia: " + distance + " KM");
                        }
                        break;
                    case 2:
                        System.out.println("Ciudad centro del grafo: " + graphCenter.getCenter());
                        break;
                    case 3:
                        System.out.println("a) Interrupción de tráfico");
                        System.out.println("b) Establecer conexión");
                        char modifyOption = scanner.nextLine().charAt(0);
                        if (modifyOption == 'a') {
                            System.out.print("Ingrese la ciudad origen: ");
                            String startInterrupt = scanner.nextLine();
                            System.out.print("Ingrese la ciudad destino: ");
                            String endInterrupt = scanner.nextLine();
                            graph.removeConnection(startInterrupt, endInterrupt);
                            floydWarshall = new FloydWarshall(graph);
                            graphCenter = new GraphCenter(floydWarshall);
                        } else if (modifyOption == 'b') {
                            System.out.print("Ingrese la ciudad origen: ");
                            String startConnect = scanner.nextLine();
                            System.out.print("Ingrese la ciudad destino: ");
                            String endConnect = scanner.nextLine();
                            System.out.print("Ingrese la distancia en KM: ");
                            int newDistance = scanner.nextInt();
                            scanner.nextLine();
                            graph.updateGraph(startConnect, endConnect, newDistance);
                            floydWarshall = new FloydWarshall(graph);
                            graphCenter = new GraphCenter(floydWarshall);
                        }
                        break;
                    case 4:
                        scanner.close();
                        return;
                    default:
                        System.out.println("Opción no válida");
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}