package covidlogistics;
import java.util.*;

public class FloydWarshall {
    public int[][] dist;
    private int[][] next;
    public List<String> cities;
    public static final int INF = Integer.MAX_VALUE;

    public FloydWarshall(Graph graph) {
        this.cities = graph.getCities();
        initialize(graph.getAdjMatrix());
        floydWarshall();
    }

    private void initialize(int[][] adjMatrix) {
        int n = adjMatrix.length;
        dist = new int[n][n];
        next = new int[n][n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                dist[i][j] = adjMatrix[i][j];
                if (adjMatrix[i][j] != INF && i != j) {
                    next[i][j] = j;
                } else {
                    next[i][j] = -1;
                }
            }
        }
    }

    private void floydWarshall() {
        int n = dist.length;

        for (int k = 0; k < n; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (dist[i][k] != INF && dist[k][j] != INF && dist[i][k] + dist[k][j] < dist[i][j]) {
                        dist[i][j] = dist[i][k] + dist[k][j];
                        next[i][j] = next[i][k];
                    }
                }
            }
        }
    }

    public List<String> getShortestPath(String start, String end) {
        int u = cities.indexOf(start);
        int v = cities.indexOf(end);
        if (u == -1 || v == -1 || dist[u][v] == INF) {
            return null;
        }
        List<String> path = new ArrayList<>();
        while (u != v) {
            path.add(cities.get(u));
            u = next[u][v];
        }
        path.add(cities.get(v));
        return path;
    }

    public int getShortestDistance(String start, String end) {
        int u = cities.indexOf(start);
        int v = cities.indexOf(end);
        return (u == -1 || v == -1) ? INF : dist[u][v];
    }
}