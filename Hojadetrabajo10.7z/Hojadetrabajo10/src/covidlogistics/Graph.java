package covidlogistics;

import java.io.*;
import java.util.*;

public class Graph {
    private int[][] adjMatrix;
    private List<String> cities;
    public static final int INF = Integer.MAX_VALUE;

    public Graph(String filename) throws IOException {
        readGraphFromFile(filename);
    }

    private void readGraphFromFile(String filename) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String line;
        cities = new ArrayList<>();
        Map<String, Integer> cityIndex = new HashMap<>();

        List<String[]> edges = new ArrayList<>();
        while ((line = br.readLine()) != null) {
            if (line.trim().isEmpty()) continue; // Ignorar líneas vacías
            String[] parts = line.split(" ");
            if (parts.length != 3) {
                br.close();
                throw new IOException("Formato incorrecto en la línea: " + line);
            }
            String city1 = parts[0];
            String city2 = parts[1];
            @SuppressWarnings("unused")
			int distance;
            try {
                distance = Integer.parseInt(parts[2]);
            } catch (NumberFormatException e) {
                br.close();
                throw new IOException("Distancia no es un número válido en la línea: " + line);
            }

            if (!cityIndex.containsKey(city1)) {
                cityIndex.put(city1, cities.size());
                cities.add(city1);
            }
            if (!cityIndex.containsKey(city2)) {
                cityIndex.put(city2, cities.size());
                cities.add(city2);
            }

            edges.add(new String[]{city1, city2, parts[2]});
        }
        br.close();

        int n = cities.size();
        adjMatrix = new int[n][n];
        for (int i = 0; i < n; i++) {
            Arrays.fill(adjMatrix[i], INF);
            adjMatrix[i][i] = 0;
        }

        for (String[] edge : edges) {
            String city1 = edge[0];
            String city2 = edge[1];
            int distance = Integer.parseInt(edge[2]);

            int i = cityIndex.get(city1);
            int j = cityIndex.get(city2);
            adjMatrix[i][j] = distance;
        }
    }

    public int[][] getAdjMatrix() {
        return adjMatrix;
    }

    public List<String> getCities() {
        return cities;
    }

    public void updateGraph(String city1, String city2, int distance) {
        int i = cities.indexOf(city1);
        int j = cities.indexOf(city2);
        if (i != -1 && j != -1) {
            adjMatrix[i][j] = distance;
        }
    }

    public void removeConnection(String city1, String city2) {
        updateGraph(city1, city2, INF);
    }

    public void printAdjMatrix() {
        int n = adjMatrix.length;
        System.out.print("    ");
        for (String city : cities) {
            System.out.printf("%8s", city);
        }
        System.out.println();
        for (int i = 0; i < n; i++) {
            System.out.printf("%4s", cities.get(i));
            for (int j = 0; j < n; j++) {
                if (adjMatrix[i][j] == INF) {
                    System.out.print("    INF");
                } else {
                    System.out.printf("%8d", adjMatrix[i][j]);
                }
            }
            System.out.println();
        }
    }
}